$(document).ready(function(){
    var mixer = mixitup('.portfolioscript');
});

$(document).ready(function(){
    $("button").click(function(){
        $(".mix").togglefade();
    }); 
});

// sticky Menu

$(document).ready(function(){
    $(window).scroll(function(){
        if(this.scrollY > 10){
            $('.navbar').addClass("sticky");
        }else{
            $('.navbar').removeClass("sticky")
        }
    });
});